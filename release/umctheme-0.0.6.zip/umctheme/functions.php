<?php
/**
 * University of Utah functions and definitions
 *
 * @package University of Utah
 * @version 0.0.6
 */

/**
 * Set the content width based on the theme's design and stylesheet.
 */
if ( ! isset( $content_width ) ) {
	$content_width = 640; /* pixels */
}

if ( ! function_exists( 'umctheme_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function umctheme_setup() {

	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on University of Utah, use a find and replace
	 * to change 'umctheme' to the name of your theme in all the template files
	 */
	load_theme_textdomain( 'umctheme', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link http://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	 */
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in two locations.
	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'umctheme' ),
		'footer' => __( 'Footer Menu', 'umctheme' ),
	) );

	// Enable support for Post Formats.
	add_theme_support( 'post-formats', array( 'aside', 'image', 'video', 'quote', 'link' ) );

	// Setup the WordPress core custom background feature.
	add_theme_support( 'custom-background', apply_filters( 'umctheme_custom_background_args', array(
		'default-color' => 'ffffff',
		'default-image' => '',
	) ) );

	// Enable support for HTML5 markup.
	add_theme_support( 'html5', array(
		'comment-list',
		'search-form',
		'comment-form',
		'gallery',
	) );
}
endif; // umctheme_setup
add_action( 'after_setup_theme', 'umctheme_setup' );


/**
 * Register widgetized area and update sidebar with default widgets.
 */
function umctheme_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Sidebar', 'umctheme' ),
		'id'            => 'sidebar-1',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => __( 'Front Page Widgets', 'umctheme' ),
		'id'            => 'front-page',
		'description'	=> 'Add all home page widgets to this location.',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
	) );

	register_sidebar( array(
		'name'          => __( 'Above Post Widgets', 'umctheme' ),
		'id'            => 'sidebar-top',
		'description'	=> 'Add widgets above the post',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
	) );

	register_sidebar( array(
		'name'          => __( 'Below Post Widgets', 'umctheme' ),
		'id'            => 'sidebar-bottom',
		'description'	=> 'Add widgets below the post',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
	) );

	register_sidebar( array(
		'name'          => __( 'Above Columns Widgets', 'umctheme' ),
		'id'            => 'sidebar-above-columns',
		'description'	=> 'Add widgets above columns in a two-column layout.',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
	) );

	register_sidebar( array(
		'name'          => __( 'Below Columns Widgets', 'umctheme' ),
		'id'            => 'sidebar-below-columns',
		'description'	=> 'Add widgets below columns in a two-column layout.',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
	) );	

}
add_action( 'widgets_init', 'umctheme_widgets_init' );


/**
* Add custom post types.
*/


/**
 * Enqueue scripts and styles.
 */
function umctheme_scripts() {

	wp_enqueue_style( 'umctheme-bootstrap', get_template_directory_uri() . '/css/bootstrap.css', array(), '20140512', 'all' );

	wp_enqueue_style( 'umctheme-magnific-popup-style', get_template_directory_uri() . '/css/magnific-popup.css', array(), '20150318', 'all' );

	wp_enqueue_style( 'umctheme-flexslider-style', '/wp-content/plugins/utah-banner-widget/flexslider.css', array(), '20140506', 'all' );

	wp_enqueue_style( 'umc-slick-style', get_template_directory_uri() . '/css/slick.css', array(), '20150220', 'all' );

	/* If using a child theme, auto-load the parent theme style. */
	if ( is_child_theme() ) {
		wp_enqueue_style( 'umctheme-parent-style', trailingslashit( get_template_directory_uri() ) . 'style.css', 'screen, print'  );
	}

	wp_enqueue_style( 'umc-theme-style', get_stylesheet_uri(), 'screen, print' );

	// BEGIN SCRIPTS

	wp_enqueue_script( 'jquery', '/wp-includes/js/jquery/jquery.js', false, '20150304', true);

	// Checking if the wp-local-config.php file exists
	$localConfig = $_SERVER['DOCUMENT_ROOT'] .'/wp-local-config.php';
	if (file_exists($localConfig)) {
	  // Load dev styles
	  // load dev js
		wp_enqueue_script( 'umctheme-navigation', get_template_directory_uri() . '/js/dev/navigation.js', array(), '20120206', true );

		wp_enqueue_script( 'umctheme-skip-link-focus-fix', get_template_directory_uri() . '/js/dev/skip-link-focus-fix.js', array(), '20130115', true );

		// wp_enqueue_script( 'umctheme-retina',  get_template_directory_uri() . '/js/dev/retina.min.js', array('jquery'), '20140602', true );

		wp_enqueue_script( 'umctheme-flexslider',  get_template_directory_uri() . '/js/dev/jquery.flexslider.js', array('jquery'), '20140506', true );

		wp_enqueue_script( 'umc-slick',  get_template_directory_uri() . '/js/dev/slick.min.js', array('jquery'), '20150220', true );

		wp_enqueue_script( 'parallax-bg-stellar',  get_template_directory_uri() . '/js/dev/jquery.stellar.js', array('jquery'), '20150209', true );

		// Allows for getting height and width of hidden elements: http://dreamerslab.com/blog/en/get-hidden-elements-width-and-height-with-jquery/
		wp_enqueue_script( 'umc-jquery-actual',  get_template_directory_uri() . '/js/dev/jquery.actual.min.js', array('jquery', 'umctheme-global'), '20150206', true );

		wp_enqueue_script( 'umctheme-global',  get_template_directory_uri() . '/js/dev/global.js', array('jquery'), '20140506', true );

	}
	else {
	  // Load Prod CSS
	  // Load Prod JS
		wp_enqueue_script( 'umctheme-combined',  get_template_directory_uri() . '/js/prod/combined.min.js', array('jquery'), '20150304', true );

	}
	// keep Magnific js from being added to combined.min.js file
	wp_enqueue_script( 'umc-magnific-popup-js',  get_template_directory_uri() . '/js/jquery.magnific-popup.min.js', array('jquery'), '20150318', true );


	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'umctheme_scripts' );

add_action('admin_head', 'admin_form_styles');

function admin_form_styles() {
  echo '<style>
textarea.utah-txt-area{
	height: 100px;
}
  </style>';
}

// Hide all Revolution slider layer style options except the "uu" styles
function rev_slider_admin_styles(){
	echo'<style>
		#ui-id-1 .ui-menu-item[original-title]{display:none;}
		#ui-id-1 .ui-menu-item[original-title*="uu"]{display:block;}
	</style>';
}

add_action('admin_head', 'rev_slider_admin_styles');


// Callback function to insert 'styleselect' into the $buttons array (which adds a styleselect dropdown menu to the second row of the tinymce buttons)
function uu_mce_buttons_2($buttons) {
	array_unshift($buttons, 'styleselect');
	return $buttons;
}
// Register our callback to the appropriate filter
add_filter('mce_buttons_2', 'uu_mce_buttons_2');

/*
* Callback function to filter the MCE settings
*/

function my_mce_before_init_insert_formats( $init_array ) {  

// Define the style_formats array

	$style_formats = array(  
		// Each array child is a format with it's own settings
		array(  
			'title' => 'Button',  
			'selector' => 'a',  
			'classes' => 'btn',
			'wrapper' => false
		),
		array(  
			'title' => 'Uppercase Button',  
			'selector' => 'a',  
			'classes' => 'btn uppercase',
			'wrapper' => false
		),
		array(  
			'title' => 'Full-Width Button',
			'selector' => 'a',  
			'classes' => 'btn btn-full-width',
			'wrapper' => false
		),
		array(  
			'title' => 'Red Button',  
			'selector' => 'a',  
			'classes' => 'btn-primary',
			'wrapper' => false
		),
		array(  
			'title' => 'Uppercase Red Button',  
			'selector' => 'a',  
			'classes' => 'btn-primary uppercase',
			'wrapper' => false
		),
		array(  
			'title' => 'Full-Width Red Button',
			'selector' => 'a',  
			'classes' => 'btn-primary btn-full-width',
			'wrapper' => false
		),
		array(  
			'title' => 'Gray Button',  
			'selector' => 'a',  
			'classes' => 'btn-secondary',
			'wrapper' => false
		),
		array(  
			'title' => 'Uppercase Gray Button',  
			'selector' => 'a',  
			'classes' => 'btn-secondary uppercase',
			'wrapper' => false
		),
		array(  
			'title' => 'Full-Width Gray Button',
			'selector' => 'a',  
			'classes' => 'btn-secondary btn-full-width',
			'wrapper' => false
		), 
		array(  
			'title' => 'Drop Cap',  
			'selector' => 'p',  
			'classes' => 'drop-cap',
			'wrapper' => false
		)
	);  
	// Insert the array, JSON ENCODED, into 'style_formats'
	$init_array['style_formats'] = json_encode( $style_formats );  
	
	return $init_array;  
  
} 
// Attach callback to 'tiny_mce_before_init' 
add_filter( 'tiny_mce_before_init', 'my_mce_before_init_insert_formats' );

function umctheme_add_editor_styles() {
    add_editor_style( 'custom-editor-style.css' );
}
add_action( 'init', 'umctheme_add_editor_styles' );

/*  Add responsive container to embeds
/* ------------------------------------ */ 
function umc_embed_html( $html ) {
    return '<div class="video-container">' . $html . '</div>';
}
 
add_filter( 'embed_oembed_html', 'umc_embed_html', 10, 3 );
add_filter( 'video_embed_html', 'umc_embed_html' ); // Jetpack

add_filter('upload_mimes', 'add_custom_mime_types');

function add_custom_mime_types($mimes){
		return array_merge($mimes,array (
			'zip' => 'application/x-compressed-zip',
		));
}


/**
 * Load CSS for IE 8 and lower
 */
function ie_style_sheets () {
	wp_register_style( 'ie8', get_template_directory_uri() . '/css/ie8.css', array('utah-grid-css'), '20140710', 'all' );
	$GLOBALS['wp_styles']->add_data( 'ie8', 'conditional', 'lte IE 8' );
	wp_enqueue_style( 'ie8');
}
add_action ('wp_enqueue_scripts','ie_style_sheets');



/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';

/**
 * Load theme customization file.
 */
require get_template_directory() . '/inc/theme-options.php';
